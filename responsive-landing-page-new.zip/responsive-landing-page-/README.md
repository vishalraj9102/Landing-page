# Responsive Landing Page Islands Travel 🏝️
## [Watch it on youtube](https://youtu.be/6GBVaHH_6bQ)
### Responsive Landing Page Islands Travel
Beautiful Responsive Landing Page Islands Travel 🏝️ Using Html, Css and JavaScript. It contains a header and a home that shows various sections of different islands.
Don't forget to join the channel for more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![Landing Page Travel](/preview.png)
